<?php
include 'dbstudi.php';

if(isset($_POST['email']))
//the user has pressed submit button
{
$email    = $_POST['email'];
$password = $_POST['password'];

$sql = "SELECT * FROM instructor_details WHERE email = '".$email."' AND password= '".$password."' limit 1"; 
$result = mysqli_query($connect,$sql);
    
    if (mysqli_num_rows($result)==1) {
      echo "<script>alert('✔ Login Successful!');
            window.location = 'ins_dash1.php';</script>";
            exit();
        

} else {
    echo "<script>alert('✖  Login failed! Invalid Email Address or Password. Try Again!');
    window.location = 'Instructor login.php';</script>";
    exit();

}
}

?>

<!DOCTYPE html>
<html lang="en" style="min-height: 100%;">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Studi - Instructor Login</title>
    
    <!-- Layout styles -->
    <link rel="stylesheet" href="Instructor login.css">
    <!-- End layout styles -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" href="logo.ico">
  </head>
  <body>

    <div class="container">

      <img class ="image" src="3.png" alt="Studi - Instructor Registration">

    <div>
        <div>
            <div>
                <div>
                  <div class="card">
                    <div>
                <h1><b>Instructor Login</b></h1><hr><br>

                <form name="instlog" method="POST" autocomplete="off">



                  <div class="form-group" style="position:relative;">
                    <label><b>Email Address</b> <font style="color: red;">*</font></label>
                    <input type="email" name="email" placeholder="Enter your correct email address" class="form-control" required>
                  </div> 

                  <div class="form-group" style="position:relative;">
                    <label><b>Password</b> <font style="color: red;">*</font></label>
                    <input type="password" name="password" placeholder="Enter your correct password" minlength="8" class="form-control" required>
                  </div>

                  <a href="forgot pass.php" class="forgot">Forgot password</a>

                  <div class="btn-container">
                    <input type="reset" name="reset" class="btn" value="Clear" >
                    <input type="submit" name="submit" class="btn" value="Login" >
                
                  
                  </div>

                  <div class="txt">
                    <font>
                      <b>(Enter your correct email address and password that you provided when in instructor registration.)</b></font>
                  </div>
<br>
                  <p class="sign-up">Don't have an Instructor Account?<a href="index.php"> <b>Register</b></a>
                    <br><b>Want to select account type again? </b><a href="Commonlogin.php"><b>Go Back</b></a></p></p>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
</div>
  </body>
</html>