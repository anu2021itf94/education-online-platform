<?php

session_start();
  


  $connect = new mysqli('localhost','root','','studi');
    if($connect->connect_error){
        die("Failed to connect : ".$connect->connect_error);
    }



    else{
        
        if (isset($_GET['delete']))
        {
           $delete = $_GET['delete'];
           $sql = "DELETE FROM user_reg WHERE email='$delete' limit 1";
           mysqli_query($connect,$sql);
           header('Location:admin_dash3.php');
        }
        
        
        
        
        //$stmt = "DELETE FROM instructor_details WHERE(title, fullname, username, nic, education, university, job, phone, password, confirmpassword)";
       // $stmtt_run = mysqli_query($connect, $stmt)."DELETE FROM instructor_details WHERE(title, fullname, username, nic, education, university, job, phone, password, confirmpassword)";
       
        
       
        }

?>       