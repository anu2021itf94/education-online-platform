<!DOCTYPE html>
<html lang="en" style="min-height: 100%;">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Studi - Common Login Section</title>

    <link rel="icon" href="logo.ico" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  
    <style>
        body {
    margin: 0;
    font-size: 1rem;
    font-family: sans-serif;
    font-weight: 400;
    line-height: 1.5;
    color: #ffffff;
    text-align: left;
    background: linear-gradient(#8739F9,#37B9F1,#F2F5F5);}

  h1{
    font-weight: 500;
    font-size: 1.5rem;
    margin-top: 0;
    margin-bottom: 0.5rem;}

*,
*::before,
*::after {
  box-sizing: border-box;}

.image{
  float: left;
border-top-left-radius: 10px;
border-bottom-left-radius: 10px;
position: sticky;
width: 50%;
height: 100%;
display:table-cell;
transform-origin: right;
margin-top: 1px;
margin-left: 23px;
transition: 0.5s;}

.container{
  max-width: 993px;
  position: relative;
  width: 100%;
  height: 100%;
  padding-top: 0.5%;
  padding-bottom: 0.8%;
  padding-right: 5.75rem;
  padding-left: 0.75rem;
  margin-right: 100px;
  margin-left: 215px;}

.card {
  position: relative;
  display: table-cell;
  padding: 3.25rem;
  height: 629px;
  background-color: #191c24; 
  border-top-right-radius: 10px;
  border-bottom-right-radius: 10px;}

.btn{
  font-weight: 400;
  color: #000000;
  text-align: center;
  border: 1px solid transparent;
  padding: 0.375rem 0.75rem;
  font-size: 0.9375rem;
  line-height: 1;
  transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out; 
  background-color: #37B9F1;
  border-radius: 15px;
  width: 100%;
  height: 40px;}

.btn:hover {
  background-color: #ffffff;
  border-color: #ffffff;
  color:#000000;
  cursor: pointer;}

  .ab{
    color: #000000;
  }

  .ab:hover{
    color: #000000;
  }

    </style>
</head>

  <body>
  
    <div class="container" style="margin-top:3px;">

        <img class ="image" src="0.png" alt="Studi - Admin Login">
  
    <div>
        <div>
            <div>
                <div>
                  <div class="card">
                    <div>
                    
                    <p style="text-align: center;"><b>How do you prefer to connect with us...! </b></p>
                    
                    <form method="get" action="#">
                    <h3>For Admin <i class="fa fa-user-secret"></i> <hr></h3>
                    <button type="submit" class="btn" style="width:130px;"><a class="ab" style="text-decoration:none;" href="admin login.php">Login</a></button><br><br>

                    <h3>For Instructors <i class="fa fa-graduation-cap"></i> <hr></h3>
                    <button type="submit" class="btn" style="width:130px;"><a class="ab" style="text-decoration:none;" href="Instructor Login.php">Login</a></button>
                    <button type="submit" class="btn" style="width:130px; margin-left: 30px;"><a class="ab" style="text-decoration:none;" href="index.php">Sign up</a></button><br><br>

                    <h3>For Users <i class="fa fa-users"></i> <hr></h3>
                    <button type="submit" class="btn" value="Login" style="width:130px; "><a class="ab" style="text-decoration:none;" href="User login.php">Login</a></button>
                    <button type="submit" class="btn" value="Sign-up" style="width:130px; margin-left: 30px;"><a class="ab" style="text-decoration:none;" href="User Registration.php">Sign up</a></button><br>


                    
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
</div>
</body>
</html>