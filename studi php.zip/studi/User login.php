<?php

include 'dbstudi.php';

if(isset($_POST['email']))
//the user has pressed submit button
{
$email    = $_POST['email'];
$password = $_POST['password'];

$sql = "SELECT * FROM user_reg WHERE email = '".$email."' AND password= '".$password."' limit 1"; 
$result = mysqli_query($connect,$sql);
    
    if (mysqli_num_rows($result)==1) {
      echo "<script>alert('✔ Login Successful!');
            window.location = 'user_dash1.php';</script>";
            exit();
        

} else {
    echo "<script>alert('✖  Login failed! Invalid Email Address or Password. Try Again!');
    window.location = 'User login.php';</script>";
    exit();

}
}

?>




<!DOCTYPE html>
<html lang="en" style="min-height: 100%;">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Studi - User Login</title>
    <!-- plugins:css -->
    
   
    <link rel="stylesheet" href="Instructor login.css">
    <link rel="icon" href="logo.ico" />
  </head>
  <body>
    <div class="container">

      <img class ="image" src="5.png"alt="Studi - User Login">
      <div >
        <div >
          <div >
            <div class="card">
              <div >
              
               <h1><b>User Login</b></h1><hr><br>

                <form name="userlog" method="POST" autocomplete="off">
              
                  <div class="form-group">
                    <label><b>Email Address</b> <font style="color: red;">*</font></label>

                    <input type="email" placeholder="Enter your correct email address" class="form-control" required>
                  </div>
                  <div class="form-group">
                    <label><b>Password</b> <font style="color: red;">*</font></label>
                    
                    <input type="password" placeholder="Enter your correct password" minlength="8" class="form-control" required>
                  </div>

                    <a href="#"  class="forgot">Forgot password</a>

                    <div class="btn-container">
                      <input type="reset" class="btn" value="Clear" >
                      <input type="submit" class="btn" value="Login" >
                  
                    
                    </div>

                    <div class="txt">
                      <font>
                        <b>(Enter your correct email address and password that you provided when in user registration.)</b></font>
                    </div><br>
              
                    <p class="sign-up">Don't have an User Account?<a href="User Registration.php"> <b>Register</b></a>
                      <br><b>Want to select account type again? </b><a href="Commonlogin.php"><b>Go Back</b></a></p>

                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>