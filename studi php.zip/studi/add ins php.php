<?php

session_start();
    $title = $_POST['title'];
    $fullname = $_POST['fullname'];
    $username = $_POST['username'];
    $nic = $_POST['nic'];
    $education = $_POST['education'];
    $university = $_POST['university'];
    $job = $_POST['job'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    $confirmpassword = $_POST['confirmpassword'];


  $connect = new mysqli('localhost','root','','studi');
    if($connect->connect_error){
        die("Failed to connect : ".$connect->connect_error);
    }

    else{
        $stmt = $connect->prepare("Insert into ins_registered (title, fullname, username, nic, education, university, job, email, phone, password, confirmpassword)
        values(?, ?, ?, ?, ?, ?,?,?,?,?,?)
        ");

        //check same password is equal with confirm password and greater than 8 characters is there
        if (($password == $confirmpassword) && (strlen($password)>=8)){

            //&& ($password != $_POST['password'])
       
        if(isset($_POST['submit'])){

            //check same password is there
            $pass = "SELECT * from ins_registered where password ='$password'";
            $p = mysqli_query($connect, $pass);

            if (mysqli_num_rows($p) >0)
            {echo "<script>alert('Password Already Exists! <br> Please enter a valid password');</script>";}
                 
            //check same username is there 
            $user = "SELECT * from ins_registered where username ='$username'";
            $u = mysqli_query($connect, $user);

            if (mysqli_num_rows($u) >0)
            {echo "<script>alert('Username Already Exists! <br> Please enter a valid username');</script>";}
                 
            //check same email is there
            $sql="SELECT * FROM ins_registered WHERE email='$email' limit 1";
            $result = mysqli_query( $connect,$sql);

            if(mysqli_num_rows($result)>0)
                {echo "<script>alert('Email Address Already Exists! <br> Please enter a valid email address');</script>";}

                //'<script>alert("Username Exist!")</script>'
                
                else{$stmt->bind_param("sssssssssss",$title, $fullname, $username, $nic, $education, $university, $job, $email, $phone, $password, $confirmpassword);
                    $stmt->execute();
                    
                    header('Location:admin_dash1.php');
                    $stmt->close();
                    $connect->close();}

                
            }
            
                
        }
                else{echo "<script>alert('Password is not matching with confirm password! <br> or <br> Password should at least 8 characters <br>
                    Please enter a valid Password');</script>";}
       
        }
    

?>       

<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Check Your Entered Details !</title>
        <link rel="icon" type="image/x-icon" href="logo1ico.ico">
    </head>
    
   
</html>
        
        
        