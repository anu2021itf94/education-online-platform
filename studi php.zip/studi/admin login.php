<?php

include 'dbstudi.php';

if(isset($_POST['email'])){
  $email=$_POST['email'];
  $password =$_POST['password'];

$query = "SELECT * FROM admin_login WHERE email = '".$email."'AND password= '".$password."' limit 1"; 

$result = mysqli_query($connect,$query);

if (mysqli_num_rows($result)==1) {

  echo "<script>alert('✔ Login Successful!');
        window.location = 'admin_dash1.php';</script>";
  
  exit();

  
}
  else{
    echo "<script>alert('✖  Login failed! Invalid Email Address or Password. Try Again!');
                  window.location = 'admin login.php';</script>";
}

}
?>

<!DOCTYPE html>
<html lang="en" style="min-height: 100%;">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Studi - Admin Login</title>
    
    <!-- Layout styles -->
    <link rel="stylesheet" href="Instructor signup style.css">
    <!-- End layout styles -->
    <link rel="icon" href="logo.ico">
  </head>
  <body>

    <div class="container" style="margin-top:2%;">

      <img class ="image" src="1.png" alt="Studi - Admin Login" style="width:500px; margin-left: 85px; border-bottom-left-radius: 10px; margin-bottom:80px;">

    <div>
        <div>
            <div>
                <div>
                  <div class="card" style="width:470px; height:533px;">
                    <div>
                <h1><b>Admin Login</b></h1><hr><br>

                <form method="POST" name="adform" action="#" autocomplete="off" style="margin-top:5px;">

                  <div class="form-group">
                    <label><b>Email Address</b> <font style="color: red;">*</font></label>
                    <input type="email" name="email" placeholder="Enter your email address" class="form-control" required>
                  </div>

                  <div class="form-group">
                    <label><b>Password</b> <font style="color: red;">*</font></label>
                    <input type="password" name="password" placeholder="Enter your password with 8 or more digits" minlength="8" class="form-control" required>
                  </div> <br>

                  <input type="reset" name="clear" class="btn" value="Clear" style="width:130px; margin-left: 25px;">
                  <input type="submit" name="submit" class="btn" value="Login" style="width:130px; margin-left: 30px;"><br><br>

                  <p class="sign-up " style="margin-top: 10px; text-align: center;"><b>Want to select account type again? </b><a href="Commonlogin.php">
                    <b>Go Back</b></a><br></p>

                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
</div>
  </body>
</html>