<?php

session_start();
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $uname = $_POST['uname'];
    $email = $_POST['email'];
    $gender = $_POST['gender'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    $conpass = $_POST['conpass'];


  $connect = new mysqli('localhost','root','','studi');
    if($connect->connect_error){
        die("Failed to connect : ".$connect->connect_error);
    }

    else{
        $stmt = $connect->prepare("Insert into user_reg(fname, lname, uname, email, gender, phone, password, conpass)
        values(?, ?, ?, ?, ?, ?,?,?)");

        //check same password is equal with confirm password and greater than 8 characters is there
        if (($password == $conpass) && (strlen($password)>=8)){

            //&& ($password != $_POST['password'])
       
        if(isset($_POST['submit'])){

            //check same password is there
            $pass = "SELECT * from user_reg where password ='$password'";
            $p = mysqli_query($connect, $pass);

            if (mysqli_num_rows($p) >0)
            {echo "<script>alert('Password Already Exists! Please enter a valid password');</script>";}
            
            //check same username is there 
            $user = "SELECT * from user_reg where uname ='$uname'";
            $u = mysqli_query($connect, $user);

            if (mysqli_num_rows($u) >0)
            {echo "<script>alert('Username Already Exists! Please enter a valid username');</script>";}
                 
            //check same email is there
            $sql="SELECT * FROM user_reg WHERE email='$email' limit 1";
            $result = mysqli_query( $connect,$sql);

            if(mysqli_num_rows($result)>0)
                {echo "<script>alert('Email Address Already Exists! Please enter a valid email address');</script>";}

                //'<script>alert("Username Exist!")</script>'
                
                else{$stmt->bind_param("ssssssss",$fname, $lname, $uname, $email, $gender, $phone, $password, $conpass);
                    $stmt->execute();
                    
                    header('Location:admin_dash3.php');
                    $stmt->close();
                    $connect->close();}

                
            }              
        }
                else{echo "<script>alert('Password is not matching with confirm password! or Password should at least 8 characters <br>
                    Please enter a valid Password');</script>";}
       
        }
    

?>       

<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Check Your Entered Details !</title>
        <link rel="icon" type="image/x-icon" href="logo1ico.ico">
    </head>
    
   
</html>
        
        
        