<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Terms and Conditions</title>
        <link rel="stylesheet" href="Home.css">
        <link rel="stylesheet" href="home2css.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="icon" type="image/x-icon" href="logo.ico">
    </head>
    
    <body>
        <header>
            <div class="navg" style="position: fixed;"> 
                <div class="logoo">
                    <label><img src="logo3.png" alt="QuizzA"></label>
                </div>
                
                <a href="Home.php">Home</a>
                <a href="Courses.php">Courses</a>
                <a href="Instructors.php">Instructors</a>
                <a href="About Us.php">About Studi</a>
                <a href="Contact.php">Contact Us</a> 
                <a href="commonlogin.php">Join Now >></a>
                
              </div>
        


<!--body-->

            <div class="slide" >
                    
                    <div class="container"> 
                        
            <div class="bottom-left">                    
                                        
                    </div>                   
                      </div>                   
                                        
                </div>

                <h1 style="font-size:30px; text-align:center; color:#000; margin-top: 100px;"><i class="fa fa-users"></i>&nbsp; T E R M S&nbsp; A N D&nbsp; C O N D I T I O N S </h1>
      
                <br>

                <h3 align="center" style="font-family: 'Arial', sans-serif; font-size: 24px; color: #333333;">These Terms and Conditions ("Agreement") govern 
                    the use of our website studi and any relate
                    d services provided by [studi] Us. By accessing or using the Website, you agree to be bound by this Agreement.</h3>



                    <!DOCTYPE html>
<html>
<head>
  <title>Terms and Conditions</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="container">
    <h2 class="section-heading">Intellectual Property</h2>
    <p class="section-content">
      1.1. Ownership: All content on the Website, including text, graphics, logos, images, videos, and 
      software, is the intellectual property of studi  or its licensors and is protected
       by applicable intellectual property laws.
    </p>
    <p class="section-content">
      1.2. License: We grant You a limited, non-exclusive, non-transferable, and revocable license to access 
      and use the Website for personal, non-commercial purposes. You may not modify, distribute, reproduce, or 
       any content from the Website without our prior written consent.
    </p>
  </div>

  <div class="container">
    <h2 class="section-heading">User Obligations</h2>
    <p class="section-content">
      2.1. Eligibility: By using the Website, You represent that You are of legal age and have the legal capacity
       to enter into this Agreement. If You are using the Website on behalf of an organization, You warrant that You have 
       the authority to bind that organization to this Agreement.
    </p>
  </div>

  <div class="container">
    <h2 class="section-heading">Limitation of Liability</h2>
    <p class="section-content">
        3.1. Disclaimer: The Website and its content are provided on an "as-is" basis without any warranties, 
        expressed or implied. We disclaim all warranties of merchantability, fitness for a particular purpose, and non-infringement.

        3.2. Limitation of Liability: To the maximum extent permitted by law, we shall not be liable for any
         direct, indirect, incidental, consequential, or special damages arising out of or in any way connected with 
         Your use of the Website or any third-party services or content accessed through the Website.
    </p>
  </div>

  <div class="container">
    <h2 class="section-heading">Indemnification</h2>
    <p class="section-content">
        You agree to indemnify and hold harmless studi and its officers, directors, employees, 
        and agents from any claims, damages, losses, liabilities, or expenses (including legal fees) arising out of or in
         connection with Your use of
         the Website, Your violation of this Agreement, or Your violation of any rights of a third party.
    </p>
  </div>

</body>
</html>

                




















<!--footer-->
<br><br><br><br><br>
        <div class="footer" style="z-index: -1; margin-bottom: 0;">
            
            <div class="table" style="z-index: -1;">
                <table class="foot" style="color: #fff; z-index: -1; font-family:poppins; font-size: 15px;">
                    <tr>
                        <td colspan="5">
                            <h2 class="set" style="font-family:poppins; text-align: center; margin-left:320px; margin-top:40px; color: #fff;">"Let's work together!"</h2>
                        </td>
                    </tr>
                    <tr>
                        <td rowspan="6"><a href="Home.php"><img src="logo3.png" width="200px" height="120px" style="margin-left:20px; margin-bottom: 65px;" class="logofoot"></a></td>  
                    </tr>
                    
                    <tr class="th" style="margin-left:-5px; color: #fff;">
                        <th style="width: 200px;" colspan="2"><u>Studi</u></th>
                        <th style="width: 20px;"></th>
                        <th style="width: 200px;" colspan="1"><u>Follow us on</u></th>
                        <td style="width: 10px;" colspan="1"><a href="privacy.php" style="text-decoration:none; color: #fff;"><b>Privacy & Policy</b></a></td>
                    </tr>

                    <tr style="line-height: 10px;">
                        <td colspan="3">2<sup>nd</sup> Floor, NET Building, &nbsp;  &nbsp;   &nbsp;</td>
                        <td><a href="https://www.facebook.com/" style="text-decoration: none; color: #fff;"><i class="fa fa-facebook"></i>&nbsp; &nbsp;
                            Facebook</a> &nbsp;  &nbsp;  &nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;</td>
                        <td style="width: 400px;"><a href="terms.php" style="text-decoration:none; color: #fff;"><b>Terms and Conditions</b></a></td>
                    </tr>

                    <tr>
                        <td colspan="2">No. 28, Main Road,</td>
                        <th style="width: 10px;"></th>
                        <td colspan="1"><a href="https://www.instagram.com/" style="text-decoration: none; color: #fff;"><i class="fa fa-instagram"></i>&nbsp; &nbsp;
                            Instagram</a></td>
                    </tr>

                    <tr>
                        <td colspan="2">Anuradhapura</td>
                        <th style="width: 10px;"></th>
                        <td><a href="https://twitter.com/" style="text-decoration: none; color: #fff;"><i class="fa fa-twitter"></i>&nbsp; &nbsp;
                            Twitter</a></td>
                    </tr>

                    <tr>
                        <td colspan="4">Contact: &nbsp; <i class="fa fa-envelope"></i>&nbsp; E-mail: &nbsp; 
                        <a href = "mailto:https://www.quizza.webcontact@gmail.com" style="text-decoration:none; color: #fff;">quizza.webcontact@gmail.com</a></td>
                        </tr>

                </table>

                <hr style="border-color:#8ebebe;">
                <table>
                    <tr style="text-align: center;">
                        <td colspan="6" style="color: #fff;"><small>Copyright &copy; 2023 StudiTeam. All Rights Reserved</small></td>
                    </tr>
                </table>
            </div>
        </div>
   
</header>
</body>
</html>