<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
<form action="" method="POST" enctype="multipart/form-data">
    <table width="50%" border="1" cellpadding="5" cellspacing="5">
        <thead>
          <tr>
            <th>Image</th>
            <th>Title</th>
            <th>Full Name</th>
            <th>User Name</th>
            <th>National Identity Card No</th>
            <th>Highest Education Qualification</th>
            <th>University / Institute</th>
            <th>Do you have a job?</th>
            <th>Email Address</th>
            <th>Phone Number</th>
          </tr>
        </thead> 

        <?php
        
          $connection = mysqli_connect("localhost","root","");
          $db = mysqli_select_db($connection,'studi');

          $query = "SELECT * FROM 'instructor_details' ";
          $query_run =  mysqli_query($connection, $query);
          
          while($row= mysqli_fetch_array($query_run));
          {
            ?>
              <tr>
                <td> <?php echo '<img src="data:image;base64,'.base64_encode($row['image']).'"alt="Image" style="width: 100px; height:100px"> '; ?></td>
                <td><?php  echo $row['Title'];  ?></td>
                <td><?php  echo $row['Full Name'];  ?></td>
                <td><?php  echo $row['User Name'];  ?></td>
                <td><?php  echo $row['National Identity Card No'];  ?></td>
                <td><?php  echo $row['Highest Education Qualification'];  ?></td>
                <td><?php  echo $row['University / Institute'];  ?></td>
                <td><?php  echo $row['Do you have a job?'];  ?></td>
                <td><?php  echo $row['Email Address'];  ?></td>
                <td><?php  echo $row['Phone Number'];  ?></td>
              </tr>


            <?php
          }
        
        ?>
    </table>
</form>
</body>
</html>