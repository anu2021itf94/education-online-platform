<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Contact us</title>
        <link rel="stylesheet" href="Home.css">
        <link rel="stylesheet" href="home2css.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="icon" type="image/x-icon" href="logo.ico">
    </head>
    
    <body>
        <header>
            <div class="navg" style="position: fixed;"> 
                <div class="logoo">
                    <label><img src="logo3.png" alt="QuizzA"></label>
                </div>
                
                <a href="Home.php">Home</a>
                <a href="Courses.php">Courses</a>
                <a href="Instructors.php">Instructors</a>
                <a href="About Us.php">About Studi</a>
                <a href="Contact.php">Contact Us</a> 
                <a href="commonlogin.php">Join Now >></a>
                
              </div>
        


<!--body-->
        
            <div class="slide" >
                    
                    <div class="container"> 
                        
            <div class="bottom-left">                    
                                        
                    </div>                   
                      </div>                   
                                        
                </div>

                <h1 style="font-size:30px; text-align:center; color:#000; margin-top: 100px;"><i class="fa fa-comments"></i>&nbsp;W E&nbsp; A R E&nbsp; H E R E </h1>
      
                <h2 style="font-size:18px; text-align:center;">"Our door is always open for a good cup of coffee."</h2>
                <br>


                <table border="1" class="foot" style="color: #000; z-index: -1; font-family:poppins; font-size: 15px;">
                    
                    <tr class="th" style="margin-left:-5px; color: #fff;">
                        <th style="width: 200px;" colspan="2"></th>
                        <th style="width: 20px;"></th>
                        <th style="width: 200px;" colspan="1"><u>Follow us on</u></th>
                    </tr>

                    <tr style="line-height: 10px;">
                        <td colspan="3">2<sup>nd</sup> Floor, NET Building, &nbsp;  &nbsp;   &nbsp;</td>
                        <td><a href="https://www.facebook.com/" style="text-decoration: none; color: #fff;"><i class="fa fa-facebook"></i>&nbsp; &nbsp;
                            Facebook</a> &nbsp;  &nbsp;  &nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;</td>
                    </tr>

                    <tr>
                        <td colspan="2">No. 28, Main Road,</td>
                        <th style="width: 10px;"></th>
                        <td colspan="1"><a href="https://www.instagram.com/" style="text-decoration: none; color: #fff;"><i class="fa fa-instagram"></i>&nbsp; &nbsp;
                            Instagram</a></td>
                    </tr>

                    <tr>
                        <td colspan="2">Anuradhapura</td>
                        <th style="width: 10px;"></th>
                        <td><a href="https://twitter.com/" style="text-decoration: none; color: #fff;"><i class="fa fa-twitter"></i>&nbsp; &nbsp;
                            Twitter</a></td>
                    </tr>

                    <tr>
                        <td colspan="4">Contact: &nbsp; <i class="fa fa-envelope"></i>&nbsp; E-mail: &nbsp; 
                        <a href = "mailto:https://www.quizza.webcontact@gmail.com" style="text-decoration:none; color: #fff;">quizza.webcontact@gmail.com</a></td>
                        </tr>

                </table>

















<!--footer-->
<br><br><br><br>
        <div class="footer" style="z-index: -1; margin-bottom: 0;">
            
            <div class="table" style="z-index: -1;">
                <table class="foot" style="color: #fff; z-index: -1; font-family:poppins; font-size: 15px;">
                    <tr>
                        <td colspan="5">
                            <h2 class="set" style="font-family:poppins; text-align: center; margin-left:320px; margin-top:40px; color: #fff;">"Let's work together!"</h2>
                        </td>
                    </tr>
                    <tr>
                        <td rowspan="6"><a href="Home.php"><img src="logo3.png" width="200px" height="120px" style="margin-left:20px; margin-bottom: 65px;" class="logofoot"></a></td>  
                    </tr>
                    
                    <tr class="th" style="margin-left:-5px; color: #fff;">
                        <th style="width: 200px;" colspan="2"><u>Studi</u></th>
                        <th style="width: 20px;"></th>
                        <th style="width: 200px;" colspan="1"><u>Follow us on</u></th>
                        <td style="width: 10px;" colspan="1"><a href="privacy.php" style="text-decoration:none; color: #fff;"><b>Privacy & Policy</b></a></td>
                    </tr>

                    <tr style="line-height: 10px;">
                        <td colspan="3">2<sup>nd</sup> Floor, NET Building, &nbsp;  &nbsp;   &nbsp;</td>
                        <td><a href="https://www.facebook.com/" style="text-decoration: none; color: #fff;"><i class="fa fa-facebook"></i>&nbsp; &nbsp;
                            Facebook</a> &nbsp;  &nbsp;  &nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;</td>
                        <td style="width: 400px;"><a href="terms.php" style="text-decoration:none; color: #fff;"><b>Terms and Conditions</b></a></td>
                    </tr>

                    <tr>
                        <td colspan="2">No. 28, Main Road,</td>
                        <th style="width: 10px;"></th>
                        <td colspan="1"><a href="https://www.instagram.com/" style="text-decoration: none; color: #fff;"><i class="fa fa-instagram"></i>&nbsp; &nbsp;
                            Instagram</a></td>
                    </tr>

                    <tr>
                        <td colspan="2">Anuradhapura</td>
                        <th style="width: 10px;"></th>
                        <td><a href="https://twitter.com/" style="text-decoration: none; color: #fff;"><i class="fa fa-twitter"></i>&nbsp; &nbsp;
                            Twitter</a></td>
                    </tr>

                    <tr>
                        <td colspan="4">Contact: &nbsp; <i class="fa fa-envelope"></i>&nbsp; E-mail: &nbsp; 
                        <a href = "mailto:https://www.quizza.webcontact@gmail.com" style="text-decoration:none; color: #fff;">quizza.webcontact@gmail.com</a></td>
                        </tr>

                </table>

                <hr style="border-color:#8ebebe;">
                <table>
                    <tr style="text-align: center;">
                        <td colspan="6" style="color: #fff;"><small>Copyright &copy; 2023 StudiTeam. All Rights Reserved</small></td>
                    </tr>
                </table>
            </div>
        </div>
   
</header>
</body>
</html>