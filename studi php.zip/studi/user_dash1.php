<?php
include 'dbstudi.php';

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Studi - User Dashboard</title>

    
    
    <link rel="stylesheet" type="text/css" href="ins_dash.css">
    <link rel="icon" href="logo.ico">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

    <body> <body style="background: linear-gradient(-55deg, #43cea2,#185a9d); height:100vh;">

<div class="side-menu" style="z-index:1;">
<div class="logoo"> <!--linear-gradient(#8739F9,#37B9F1,#7accf0)-->
        <label><img src="logo3.png" style="margin-top:5px;" alt="QuizzA"></label>
    </div>
<br><br>
<br>
     <br>
     
         
            <h2 style="text-align: left;">&nbsp; <i class="fa fa-dashboard"></i> &nbsp; User Dashboard</h2><br>
            <hr style="margin-left:0px; padding-left: 2px; padding-right: 2px; margin-top: -15px;">
            
    
        <br> 
            <a href="#"><i class="fa fa-user"></i><span>Your Profile</span></a> 
            <a href="#"><i class="fa fa-book"></i><span>Enrolled Courses</span></a>

            <a href="#"><i class="fa fa-arrow-left"></i><span>Back to Studi Home</span></a> 
            <a href="#" style="margin-top:240px;"><i class="fa fa-sign-out"></i><span>Log Out</span></a>
                             
            
    </div>


    <div class="formms">

      <div class="hi" style="margin-top:-20px; margin-left: 270px;">
        <table style="line-height: 45px; text-align:left; color: black; font-size:25px; font-family: 'Poppins', sans-serif;">
                  <tr>
                    <th>Hello!! Welcome</th>
                  </tr>
        </table>
        <h3 style="font-family: 'Poppins', sans-serif; color: #000000;">Here are the details of your instructor profile in Studi.</h3><br>
          <hr style="margin-left:0px; border-color:#8ebebe; padding-left: 2px; margin-top: -15px; size: 10px;">
        <br>
      </div>

            <form id="registration-form" method="POST" name="insf1" class="Upro" style="border-color:#8ebebe; margin-bottom: 138px; width:325px;">
                <h3>Update Your Profile</h3><br>
                <hr style="margin-left:0px; padding-left: 2px; border-color:#8ebebe;  padding-right: 2px; margin-top: -15px; size: 10px;">

                <label for="username">Username:</label>
                <input type="text" id="username" name="username" placeholder="Enter your username" minlength="5" required="required">
                <br>
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" placeholder="Enter your password with 8 or more digits" minlength="8" required="required">
                <br>
                <label for="confirmpassword">Confirm Password:</label>
                <input type="password" id="confirmpassword" name="confirmpassword" placeholder="Confirm your password" minlength="8" required="required">
                <br>
                <input type="submit" value="Update">

      </form>
    </div>

<div class="formmm">
      <form action="insf2" method="POST" class="detailss"style="border-color:#8ebebe; margin-left:210px; margin-top: -140px;">
            

        <table style="margin-left:-5px; width:700px; line-height: 45px; text-align:left; font-family: 'Poppins', sans-serif;">
          <h3 style="font-family: 'Poppins', sans-serif; color: #ffffff;">Your Profile Details <font style="font-size:13px;">(These information can not change!)</font></h3><br>
          <hr style="margin-left:0px; border-color:#8ebebe;  padding-left: 2px; padding-right: 2px; margin-top: -15px; size: 10px;">
              <tr class="trs">
                  <th>E-mail Address:</th>
              </tr>
              <tr>
                  <th>Gender:</th>
              </tr>
              <tr>
                  <th>Phone Number:</th>
              </tr>

        
      </form>
</div>

    
</body>

</html>