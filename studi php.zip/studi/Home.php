<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Home</title>
        <link rel="stylesheet" href="Home.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="icon" type="image/x-icon" href="logo.ico">
    </head>
    
    <body>
        <header>
            <div class="navg"> 
                <div class="logoo">
                    <label><img src="logo3.png" alt="Studi"></label>
                </div>
                
                <a href="Home.php">Home</a>
                <a href="Courses.php">Courses</a>
                <a href="Instructors.php">Instructors</a>
                <a href="About Us.php">About Studi</a>
                <a href="Contact.php">Contact Us</a> 
                <a href="commonlogin.php">Join Now >></a>
                
              </div>
        


<!--body-->

            <div class="slide" >
                <div class="images">
                    
                    <div class="container"> 
                        <img src="h1.png" class="i1" alt="Welcome1" style="z-index: -1;">   

                        <div class="bottom-left"><h1 class="bottom-left1" style="font-size:50px; ">Marketing <h1 class="bottom-left2" style="font-size:40px;"> for Startups</h1> </h1>
                                                jhgbujmjbnghbnj mj,mnn jnv fvcbgfvnhbhjnjmhhg <br>
                                                edftcgyvuihulijkhgfdfghjkhg fhgjyhj edfhjgyhj <br>
                                                rdfygtuhujlk dfgjhkj rtfth <br><br>
                  <button class="getset" name="getset" style="z-index: 1;">
                  <a href="Commonlogin.php" style="color:#fff; text-decoration:none;">
                  <h3><span class="sp">Get Start!</span></h3></a></button>
                                            
                    </div>                   
                      </div>                   
                                        
                </div>
            </div>

            <h1 style="text-align:center; color: blanchedalmond; font-size:45px;">"One Goal, One Passion" </h1><br>
            

            <!--body second part-->
            <!--1st row-->
                <h1 style="font-size:25px; text-align:center; color:#000;">"The only marketing agency you'll ever need"</h1><br>

                <h1 style="font-size:25px; text-align:center;">
                    This text block gives a brief<br>
                    overview of your company.<br>
                    Share your philosophy,<br>
                    vision, or mantra here.</h1><br>
                                
                <h2 style="font-size:18px; text-align:center;">-Studi Team</h2>
                <br><br><br><br>
            
            <!--2nd row-->
                             
                        <img src="h2.png" class="i1" alt="Welcome2" style="z-index: 1;">                   

                <div class="bottom-left3"><h1 style="font-size:50px;">What is Studi?</h1>
                    <table width="450px">
                        <tr>
                        <td style="text-align: justify;">
                        QuizzA is an online platform, which is created to improve general knowledge in peoples' mind in some level. 
                        This is an online quiz platform so in here, you can follow quizzes in different categories. Our target is giving 
                        knowledge to you.So, always think, read, follow, and be positive.
                        <br><br>
                        QuizzA is an online platform, which is created to improve general knowledge in peoples' mind in some level. 
                        This is an online quiz platform so in here, you can follow quizzes in different categories.
                    </td>
                </tr>
</table>
                    </div>
            
        <!--3rd row-->                 
                        <img src="h3.png" class="i1" alt="Welcome3" style="z-index: -1; margin-top: -8px;">                   
            
            <div class="bottom-left4"><h1 style="font-size:40px; ">Want To Become A Learner?</h1>
                <table width="600px">
                    <tr>
                    <td style="text-align: justify;">
                        In QuizzA, there are some categories for follow to you. Technological QuizzA, Geographical QuizzA and there will be 
                        add more categories in the future. In Technological QuizzA, you will get quizzes about in Information Technology area 
                        and in Geographical QuizzA, quizzes are created about in World and Sri Lankan Geographical area.
                    </td>
                </tr>

                       <button class="getset2" name="getset" style="z-index: 1;">
                        <a href="User login.php" style="color:#fff; text-decoration:none;">
                        <h3><span class="sp">Login</span></h3></a></button>

                        <button class="getset3" name="getset" style="z-index: 1;">
                            <a href="User Registration.php" style="color:#fff; text-decoration:none;">
                            <h3><span class="sp">Register To Become Our Learner</span></h3></a></button>
                            </table>
                    </div>

        <!--4th row-->
            <div style="height: 90vh;">
        <img src="h4.png" class="i1 h4" alt="Welcome4" >
        
        <div class="bottom-left5"><h1 style="font-size:40px;">Want To Become An Instructor?</h1>
            <table width="600px">
                <tr>
                <td style="text-align: justify;">
                In QuizzA, there are some categories for follow to you. Technological QuizzA, Geographical QuizzA and there will be 
                add more categories in the future. In Technological QuizzA, you will get quizzes about in Information Technology area 
                and in Geographical QuizzA, quizzes are created about in World and Sri Lankan Geographical area.
                <br>
                <br>
                In QuizzA, there are some categories for follow to you. Technological QuizzA, Geographical QuizzA and there will be 
                add more categories in the future.
               </td>
               </tr>
               

               <button class="getset4" name="getset">
                <a href="Instructor signup.php" style="color:#000000; text-decoration:none;">
                <h3><span class="sp">Apply To Become An Instructor</span></h3></a></button>
            </table>
            </div>
        </div>
            
<!--footer-->

        <div class="footer" style="z-index: -1;">
            
            <div class="table" style="z-index: -1;">
                <table class="foot" style="color: #fff; z-index: -1; font-family:poppins; font-size: 15px;">
                    <tr>
                        <td colspan="5">
                            <h2 class="set" style="font-family:poppins; text-align: center; margin-left:320px; margin-top:40px; color: #fff;">"Let's work together!"</h2>
                        </td>
                    </tr>
                    <tr>
                        <td rowspan="6"><a href="Home.php"><img src="logo3.png" width="200px" height="120px" style="margin-left:20px; margin-bottom: 65px;" alt="Studi" class="logofoot"></a></td>  
                    </tr>
                    
                    <tr class="th" style="margin-left:-5px; color: #fff;">
                        <th style="width: 200px;" colspan="2"><u>Studi</u></th>
                        <th style="width: 20px;"></th>
                        <th style="width: 200px;" colspan="1"><u>Follow us on</u></th>
                        <td style="width: 10px;" colspan="1"><a href="privacy.php" style="text-decoration:none; color: #fff;"><b>Privacy & Policy</b></a></td>
                    </tr>

                    <tr style="line-height: 10px;">
                        <td colspan="3">2<sup>nd</sup> Floor, NET Building, &nbsp;  &nbsp;   &nbsp;</td>
                        <td><a href="https://www.facebook.com/" style="text-decoration: none; color: #fff;"><i class="fa fa-facebook"></i>&nbsp; &nbsp;
                            Facebook</a> &nbsp;  &nbsp;  &nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;</td>
                        <td style="width: 400px;"><a href="terms.php" style="text-decoration:none; color: #fff;"><b>Terms and Conditions</b></a></td>
                    </tr>

                    <tr>
                        <td colspan="2">No. 28, Main Road,</td>
                        <th style="width: 10px;"></th>
                        <td colspan="1"><a href="https://www.instagram.com/" style="text-decoration: none; color: #fff;"><i class="fa fa-instagram"></i>&nbsp; &nbsp;
                            Instagram</a></td>
                    </tr>

                    <tr>
                        <td colspan="2">Anuradhapura</td>
                        <th style="width: 10px;"></th>
                        <td><a href="https://twitter.com/" style="text-decoration: none; color: #fff;"><i class="fa fa-twitter"></i>&nbsp; &nbsp;
                            Twitter</a></td>
                    </tr>

                    <tr>
                        <td colspan="4">Contact: &nbsp; <i class="fa fa-envelope"></i>&nbsp; E-mail: &nbsp; 
                        <a href = "mailto:https://www.quizza.webcontact@gmail.com" style="text-decoration:none; color: #fff;">quizza.webcontact@gmail.com</a></td>
                        </tr>

                </table>

                <hr style="border-color:#8ebebe;">
                <table>
                    <tr style="text-align: center;">
                        <td colspan="6" style="color: #fff;"><small>Copyright &copy; 2023 StudiTeam. All Rights Reserved</small></td>
                    </tr>
                </table>
            </div>
        </div>
   
</header>
</body>
</html>