-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2023 at 02:15 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studi`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `email` varchar(100) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`email`, `password`) VALUES
('swarnamalisilva2000@gmail.com', 'Swarne2000');

-- --------------------------------------------------------

--
-- Table structure for table `instructor_details`
--

CREATE TABLE `instructor_details` (
  `title` varchar(10) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `nic` varchar(100) NOT NULL,
  `education` varchar(100) NOT NULL,
  `university` varchar(100) NOT NULL,
  `job` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` int(10) NOT NULL,
  `password` varchar(15) NOT NULL,
  `confirmpassword` varchar(15) NOT NULL,
  `instructor_pic` longblob NOT NULL,
  `reg_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `instructor_details`
--

INSERT INTO `instructor_details` (`title`, `fullname`, `username`, `nic`, `education`, `university`, `job`, `email`, `phone`, `password`, `confirmpassword`, `instructor_pic`, `reg_time`) VALUES
('Miss', 'Lalindya Nethmi Kodikara', 'Lalindya Kodikara', '200069215348', 'Higher National Diploma in Information Technology', 'Advanced Technological Institute - SLIATE', 'No', 'lalindyakodikara3105@gmail.com', 715655436, 'lalindya3105', 'lalindya2000', '', '2023-05-18 12:40:21'),
('Mr.', 'Sakun Ravisanka Premaratne', 'Sakun Ravisanka', '200065947823', 'Higher National Diploma in Information Technology', 'Advanced Technological Institute - SLIATE', 'No', 'sakunravisanka1@gmail.com', 789619294, 'sakun2000', 'sakun2000', '', '2023-05-18 12:43:02'),
('Miss', 'Sithara Thathsarani Ranasinghe', 'Sithara Thathsarani', '200035742519', 'Higher National Diploma in Information Technolog', 'Advanced Technological Institute - SLIATE', 'No', 'sithuthathsarani2000@gmail.com', 740619105, 'sithara2000', 'sithara2000', '', '2023-05-18 12:48:22'),
('Miss', 'Kaushalya S. Silva', 'Kaushalya Silva', '200062548559', 'Higher National Diploma in Information Technology', 'Advanced Technological Institute - SLIATE', 'No', 'swarnamalisilva2000@gmail.com', 774007990, 'ishwari2000', 'ishwari2000', '', '2023-05-18 12:35:38'),
('Miss', 'Vindya S. Wickramasinghe', 'Vindya Wikramasinghe', '200089579845', 'Higher National Diploma in Information Technology', 'Advanced Technological Institute - SLIATE', 'No', 'vindyawickramasinghe03@gmail.com', 719553395, 'vindya2000', 'vindya2000', '', '2023-05-18 12:46:10');

-- --------------------------------------------------------

--
-- Table structure for table `ins_registered`
--

CREATE TABLE `ins_registered` (
  `title` varchar(10) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `nic` varchar(100) NOT NULL,
  `education` varchar(100) NOT NULL,
  `university` varchar(100) NOT NULL,
  `job` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` int(10) NOT NULL,
  `password` varchar(15) NOT NULL,
  `confirmpassword` varchar(15) NOT NULL,
  `instructor_pic` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user_reg`
--

CREATE TABLE `user_reg` (
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `uname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `phone` int(10) NOT NULL,
  `password` varchar(100) NOT NULL,
  `conpass` varchar(100) NOT NULL,
  `reg_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_reg`
--

INSERT INTO `user_reg` (`fname`, `lname`, `uname`, `email`, `gender`, `phone`, `password`, `conpass`, `reg_time`) VALUES
('dsfdfg', 'dgfnghgn', 'ffedgfg erghn', 'egrb@rfgg.gfgnhgnb', 'f', 741852963, 'asdfghjff', 'asdfghjff', '2023-05-20 14:29:05'),
('xxfdgfchj', 'cvfhgvjh', 'dxfbcngvhn', 'sdxc@rgdf.rfdvx', 'm', 2147483647, 'fdxgfchjbkhj', 'dsfgjhjjm,', '2023-05-20 13:25:25');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `instructor_details`
--
ALTER TABLE `instructor_details`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `ins_registered`
--
ALTER TABLE `ins_registered`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `user_reg`
--
ALTER TABLE `user_reg`
  ADD PRIMARY KEY (`email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
