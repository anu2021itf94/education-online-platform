<?php 
session_start();

$dbserver = "localhost";
$dbuser = "root";
$dbpassword = "";
$database = "studi";

//building mysqli connection using these parameters

$connect = mysqli_connect($dbserver, $dbuser, $dbpassword, $database);

if ($connect)
{
    //echo "Success2";
}
else{
    //die("connect fail" . mysqli_connect_error());
}


?>