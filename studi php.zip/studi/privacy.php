<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Privacy and Policy</title>
    <link rel="stylesheet" href="Home.css">
    <link rel="stylesheet" href="home2css.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" type="image/x-icon" href="logo.ico">
</head>

<body>
<header>
    <div class="navg" style="position: fixed;"> 
        <div class="logoo">
            <label><img src="logo3.png" alt="QuizzA"></label>
        </div>
        <a href="Home.php">Home</a>
                <a href="Courses.php">Courses</a>
                <a href="Instructors.php">Instructors</a>
                <a href="About Us.php">About Studi</a>
                <a href="Contact.php">Contact Us</a> 
                <a href="commonlogin.php">Join Now >></a>
    </div>

    <div class="slide">
        <div class="container"> 
            <div class="bottom-left">                    
            </div>                   
        </div>                   
    </div>

    <h1 style="font-size:30px; text-align:center; color:#000; margin-top: 100px;"><i class="fa fa-shield"></i>&nbsp; &nbsp; P R I V A C Y&nbsp; A N D&nbsp; P O L I C Y </h1>
  
    <h2 style="font-size:18px; text-align:center;">"Privacy is what gives you the ability to share with the world who you are on your own terms."</h2>
    <br>

    <h3 align="center" style="font-family: 'Arial', sans-serif; font-size: 24px; color: #333333;">When you use studi websites and applications, various types of personally identifiable and non-personally identifiable information about you may become available or be purposefully collected by studi and third parties that provide site usage statistics services to us.

        studi is committed to keeping such data confidential and does not seek to gather any personal information aside from that which allows us to provide you with a quality service, analyze the readability of our own content and functionality of our web and mobile products. 
        </h3>
    
        <div class="container">
            <h2 class="section-heading">What information we collect</h2>
            <p class="section-content">
                <ul>
                    <li>Your email address, as well as other information about yourself (e.g., user name, name, phone number) you are either required to fill in or choose to disclose to us if you decide to register at dailynews.lk</li>
                    <li>Information acquired using cookies stored on your computer or device that allow us to recognize you when you return to a Daily News website (You can use your browser settings to change your privacy preferences regarding the use of cookies)</li>
                    <li>Any information about yourself you choose to make public when commenting on a studi website</li>
                    <li>Your list of favorite stories in the event you choose to establish one in your studi profile</li>
                    <li>Any information about yourself that you choose to disclose through an email sent to us</li>
                    <li>Personal information that becomes available to us when you access our content or use our applications through third-party websites and platforms (e.g., social networks)</li>
                    <li>Your IP address, as well as information about your browser, type of operating system, type of handheld or mobile device you are using to access Daily News websites and applications</li>
                    <li>Non-personally identifiable data collected by third parties gathering user-behavior statistics on RT websites for us, which includes information about the location from which our websites are accessed and information about the content viewed</li>
                </ul>
            </p>
        </div>
    
        <div class="container">
            <h2 class="section-heading">How we may use personal information</h2>
            <p class="section-content">
                <ul>
                    <li>Provide you with our online content</li>
                    <li>Personalize your Daily News experience</li>
                    <li>Receive feedback from you and respond to it</li>
                    <li>Contact you about anything you may submit to Daily News</li>
                    <li>Analyze user behavior in order to improve our web and mobile products</li>
                    <li>Block attempts to disrupt the work of our websites and applications</li>
                    <li>Prevent violations of Daily News comment posting rules</li>
                </ul>
            </p>
        </div>
    
        <h3 align="center" style="font-family: 'Arial', sans-serif; font-size: 18px; color: #333333;">studi strives to keep your personal information from being accessed by unauthorized third parties
            by using reasonable means to safeguard it. However, as transfer 
            of any kind of data over the internet is never 100 per cent secure, we cannot give you 
            any guarantees and urge you to be cautious when disclosing sensitive information. Changes

           studimay update this Privacy policy periodically. We advise
            you to review this document from time to time. If you have any comments or
             enquiries you are welcome to contact us using the Feedback form
            </h3>
       

    <div class="footer" style="z-index: -1; margin-bottom: 0;">
        <div class="table" style="z-index: -1;">
            <table class="foot" style="color: #fff; z-index: -1; font-family:poppins; font-size: 15px;">
                <tr>
                    <td colspan="5">
                        <h2 class="set" style="font-family:poppins; text-align: center; margin-left:320px; margin-top:40px; color: #fff;">"Let's work together!"</h2>
                    </td>
                </tr>
                <tr>
                    <td rowspan="6"><a href="Home.php"><img src="logo3.png" width="200px" height="120px" style="margin-left:20px; margin-bottom: 65px;" class="logofoot"></a></td>  
                </tr>
                <tr class="th" style="margin-left:-5px; color: #fff;">
                    <th style="width: 200px;" colspan="2"><u>Studi</u></th>
                    <th style="width: 20px;"></th>
                    <th style="width: 200px;" colspan="1"><u>Follow us on</u></th>
                    <td style="width: 10px;" colspan="1"><a href="privacy.php" style="text-decoration:none; color: #fff;"><b>Privacy & Policy</b></a></td>
                </tr>
                <tr style="line-height: 10px;">
                    <td colspan="3">2<sup>nd</sup> Floor, NET Building, &nbsp;  &nbsp;   &nbsp;</td>
                    <td><a href="https://www.facebook.com/" style="text-decoration: none; color: #fff;"><i class="fa fa-facebook"></i>&nbsp; &nbsp;
                        Facebook</a> &nbsp;  &nbsp;  &nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;</td>
                    <td style="width: 400px;"><a href="terms.php" style="text-decoration:none; color: #fff;"><b>Terms and Conditions</b></a></td>
                </tr>
                <tr>
                    <td colspan="2">No. 28, Main Road,</td>
                    <th style="width: 10px;"></th>
                    <td colspan="1"><a href="https://www.instagram.com/" style="text-decoration: none; color: #fff;"><i class="fa fa-instagram"></i>&nbsp; &nbsp;
                        Instagram</a></td>
                </tr>
                <tr>
                    <td colspan="2">Anuradhapura</td>
                    <th style="width: 10px;"></th>
                    <td><a href="https://twitter.com/" style="text-decoration: none; color: #fff;"><i class="fa fa-twitter"></i>&nbsp; &nbsp;
                        Twitter</a></td>
                </tr>
                <tr>
                    <td colspan="4">Contact: &nbsp; <i class="fa fa-envelope"></i>&nbsp; E-mail: &nbsp; 
                    <a href="mailto:https://www.quizza.webcontact@gmail.com" style="text-decoration:none; color: #fff;">quizza.webcontact@gmail.com</a></td>
                </tr>
            </table>
            <hr style="border-color:#8ebebe;">
            <table>
                <tr style="text-align: center;">
                    <td colspan="6" style="color: #fff;"><small>Copyright &copy; 2023 StudiTeam. All Rights Reserved</small></td>
                </tr>
            </table>
        </div>
    </div>
</body>
</html>

