<?php 

include 'dbstudi.php';


?>


<!DOCTYPE html>
<html lang="en" style="min-height: 160%;">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Studi - Instructor Accept and Register</title>
    
    <!-- Layout styles -->
    <link rel="stylesheet" href="Instructor signup style.css">
    <!-- End layout styles -->
    <link rel="icon" href="logo.ico">
  </head>
  <body>

    <div class="container">

      <img class ="image" src="2.png" alt="Studi - Instructor Registration">

    <div>
        <div>
            <div>
                <div>
                  <div class="card" style="margin-bottom: 1%;">
                    <div>
                <h1><b>Instructor Registration</b></h1><hr><br>

                <form method="POST" action="index.php">

                  <div class="form-group" required>
                    <label style="margin-top: 5px;"><b>Title</b> <font style="color: red;">*</font>&nbsp;</label>
                    <select class ="options" name="title" required>
                    <option></option>
                    <option value = "Mr.">Mr.</option>
                    <option value = "Mrs.">Mrs.</option>
                    <option value ="Miss">Miss</option>
                    </select>
                  </div>


                  <div class="form-group">
                    <label><b>Full Name</b> <font style="color: red;">*</font></label>
                    <input type="text" name="fullname" placeholder="Enter your full name with initials" class="form-control" style="height: 2.175rem;" required>
                  </div>

                  <div class="form-group">
                    <label><b>User Name</b> <font style="color: red;">*</font></label>
                    <input type="text" name="username" placeholder="Enter your user name" minlength="5" class="form-control" style="height: 2.175rem;" required>
                  </div>

                  <div class="form-group">
                    <label><b>National Identity Card No.</b> <font style="color: red;">*</font></label>
                    <input type="text" name="nic" placeholder="National Identity Card Number" class="form-control" style="height: 2.175rem;" required>
                  </div>

                  <div class="form-group">
                    <label><b>Highest Education Qualification</b> <font style="color: red;">*</font> <br>(in Information Technology Subject Area)</label>
                    <input type="text" name="education" placeholder = "Degree or Diploma" class="form-control" style="height: 2.175rem;" required>
                  </div>

                  <div class="form-group">
                    <label><b>University / Institute</b> <font style="color: red;">*</font></label>
                    <input type="text" name="university" placeholder="Enter your university or institute" class="form-control" style="height: 2.175rem;" required>
                  </div>

                  <div class="form-group">
                    <label><b>Do you have a job? </b> <font style="color: red;">*</font></label>

                    <input type="radio" id="yess" name="job" value="Yes" required="required">
                    <label for="yess" style="font-size: 14px; margin-top: -4px;">Yes</label>

                    <input type="radio" id="noo" name="job" value="No">
                    <label for="noo" style="font-size: 14px; margin-top: -4px;">No</label>
                  </div>

                  <div class="form-group">
                    <label><b>Email Address</b> <font style="color: red;">*</font></label>
                    <input type="email" name="email" placeholder="Enter your email address" class="form-control" style="height: 2.175rem;" required>
                  </div>

                  <div class="form-group">
                    <label><b>Phone Number</b> <font style="color: red;">*</font></label>
                    <input type="number" placeholder="Phone Number" name="phone" maxlength="10" class="form-control" style="height: 2.175rem;" required>
                  </div>

                  <div class="form-group">
                    <label><b>Password</b> <font style="color: red;">*</font></label>
                    <input type="password" name= "password" placeholder="Enter your password with 8 or more digits" minlength="8" class="form-control" style="height: 2.175rem;" required>
                  </div>

                  <div class="form-group">
                    <label><b>Confirm Password</b> <font style="color: red;">*</font></label>
                    <input type="password" name="confirmpassword" placeholder="Confirm your password" class="form-control" minlength="8" style="height: 2.175rem;" required>
                  </div>


                  <div class="propic" style="font-size: 0.875rem;">
                    <label for="input-file"><b>Upload Profile Picture</b> <font style="color: red;">*</font></label>
                    <input type="file" id="input-file" name= "picup" accept="image/jpeg, image/jpg, image/png" required="required">
                    </div>

                </div>
              </div>
            </div>
          </div>
        </div>
    </div>


                  <div class="container2" style="position:absolute; margin-top: -258px; height:258px;">
                    <div>
                        <div>
                            <div>
                              <div class="card2">
                                <div>

                  <form method="get" action="#" style="float:right; margin-bottom: 0px; text-align: center;">

                  <div class="form-group"  style="margin-top: -25px; text-align: left;">
                    <input type="checkbox" name="checked" required><font style="font-size: 13px; text-align:justify;">
                      I agree to all the terms and conditions and all information that I provided above is true. 
                      Also, I agree with that if I had to prove this information.<font style="color: red;">*</font></font> 

                      <font class="sign-up " style="text-align:left; margin-top: 10px; font-size: 13px; ">By creating an account you are accepting our<a href="#"> <b> Terms & Conditions</b></a></font>
                  </div>

                  
                  <div>
                    <input type="reset" class="btn" name= "reset" value="Clear" style="float:left; margin-top: 5px; width:110px; margin-left: 50px;">
                  </div>

                  <div style="float:left; margin-top: -33px; margin-left: 203px; position: relative; width:150px;">
                  <input type="submit" class="btn" name="submit" value="Apply for Register">
                  </div>


                  <p class="sign-up " style="margin-top: 65px; margin-left: 5px; font-size: 13px;">Already have an instructor account?<a href="Instructor login.php"> <b>Login</b></a>
                  <br><b>Want to select account type again? </b><a href="Commonlogin.php">
                    <b>Go Back</b></a><br></p>
                </form>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</div>
</form>
  </body>
</html>