<!DOCTYPE html>
<html lang="en" style="min-height: 100%;">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Studi - Instructor Login</title>
    
    <!-- Layout styles -->
    <link rel="stylesheet" href="forgotpass.css">
    <!-- End layout styles -->
    <link rel="icon" href="logo.ico">
  </head>
  <body>

    <div class="container">

      <img class ="image" src="3.png" alt="Studi - Instructor Registration">

    <div>
        <div>
            <div>
                <div>
                  <div class="card">
                    <div>
                <h1><b>Instructor Login</b></h1><hr><br>

                <form method="POST" action="#" autocomplete="off">

                  <div class="form-group">
                    <label><b>Forgot your password?</b></label>  
                  </div>

                  <div class="txt">
                    <font>
                      Please enter your email address so we can send you an email with a link to reset your password.</font>
                  </div>

                  <br>

                  <div class="form-group">
                    <label><b>Email Address</b> <font style="color: red;">*</font></label>
                    <input type="email" placeholder="Enter your correct email address" class="form-control" required>
                  </div>

                  <div class="btn-container">
                    <input type="submit" class="btn" value="Submit" >          
                  </div>


                  <p class="sign-up">Don't have an Instructor Account?<a href="Instructor Registration.php"> <b>Register</b></a>
                    <br><b>Want to select account type again? </b><a href="Commonlogin.php"><b>Go Back</b></a></p></p>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
    </div>
</div>
  </body>
</html>