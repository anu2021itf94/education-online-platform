<?php

include 'dbstudi.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Studi - Admin Dashboard</title>

    
    
    <link rel="stylesheet" type="text/css" href="ins_dash.css">
    <link rel="icon" href="logo.ico">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style type="text/css">
   .t2 {
    border-collapse: collapse;
    border: none;
  }
  .t2 tr {
    border-top: 1px solid black;
  }

  .t2 td {
    border: none !important;
  }
  .t2 th,td { padding:4.5px;}
    </style>

</head>

    <body style="background: linear-gradient(-55deg, #43cea2,#185a9d); height:200vh;"> 
    
    <div class="side-menu" style="z-index:1;">
    <div class="logoo"> <!--linear-gradient(#8739F9,#37B9F1,#7accf0)-->
            <label><img src="logo3.png" style="margin-top:5px;" alt="QuizzA"></label>
        </div>
<br><br>
   <br>
         <br>
            <h2><i class="fa fa-dashboard"></i>&nbsp; Admin Dashboard</h2><br>
            <hr style="margin-left:0px; padding-left: 2px; padding-right: 2px; margin-top: -15px;"><br>

            <a href="admin_dash1.php" style="cursor:pointer;"><i class="fa fa-user-plus"></i> <span>Applied Instructors</span></a>
            <a href="admin_dash2.php"><i class="fa fa-graduation-cap"></i> <span>Registered Instructors</span></a>
            <a href="admin_dash3.php"><i class="fa fa-users"></i> <span>Registered Users</span></a>

            <a href="Home.php"><i class="fa fa-arrow-left"></i><span>Back to Studi Home</span></a> 
            <a href="#" style="margin-top:180px;"><i class="fa fa-sign-out"></i><span>Log Out</span></a>
                              
            
    </div>


    <div class="formms">

      <div class="hi" style="margin-top:-20px; margin-left: 270px;">
        <table style="line-height: 45px; text-align:left; color: black; font-size:25px; font-family: 'Poppins', sans-serif;">
                  <tr>
                    <th>Hello!! Welcome Admin, <i class="fa fa-user-secret"></i>👋</th>
                  </tr>
        </table>
        <h3 style="font-family: 'Poppins', sans-serif; color: #000000;">Here is the list of registered users in Studi <font style="font-size:13px;">(User self-registration)</font></h3><br>
          <hr style="margin-left:0px; border-color:#8ebebe; padding-left: 2px; margin-top: -15px; size: 10px;">
        <br>
</div>


      <form name="insf2" method="get" class="detailss" style="border:none; max-width: 1080px; margin-left: 263px;  margin-top: -8px;">
            

      
      <table name="t2" style="line-height:54px; border-bottom: 1px solid black; border-color:#000000; text-align:center max-width:1500px; margin-left:-12px;text-align:left; font-size:12px; font-family: 'Poppins';">
              <tr style="text-align:center; background-color:#8ebebe;">
                  <th style="border-bottom: 1px solid black; text-align:center">First Name</th>
                  <th style="border-bottom: 1px solid black;">Last Name</th>
                  <th style="border-bottom: 1px solid black;">User Name</th>
                  <th style="border-bottom: 1px solid black;">E-mail Address</th>
                  <th style="border-bottom: 1px solid black;">Gender</th>
                  <th style="border-bottom: 1px solid black;">Phone Number</th>
                  <th style="border-bottom: 1px solid black;">Password</th>
              </tr>

<?php

    //create a query
    $sql = "SELECT * FROM user_reg";

    //querying (query run in database)

    $result = mysqli_query($connect, $sql);

    //check results
    $resultcheck = mysqli_num_rows($result);

    //if number result>0
    if($resultcheck > 0){
        //print the results using while loop
        //while loop using for check and collect data row by row

        while($row = mysqli_fetch_assoc($result)){

?>
            <tr style="line-height:35px; border-bottom: 1px solid black;">
                <td><?php echo $row['fname']; ?></td>
                <td><?php echo $row['lname']; ?></td>
                <td><?php echo $row['uname']; ?></td>
                <td><?php echo $row['email']; ?></td>
                <td style="text-align:center;"><?php echo $row['gender']; ?></td>
                <td style="text-align:center;"><?php echo $row['phone']; ?></td>
                <td><?php echo $row['password']; ?></td>

                  <td ><button class="reset" name="delete" style="border-radius: 10px 10px 10px 10px; height:28px; border-color:brown; background-color:brown; margin-right:8px; margin-left:8px; width:105px; margin-top: -18px;">
                  <a href="remove user php.php?delete=<?php echo $row['email'];?>" style="color:#fff; text-decoration:none" 
                  onClick ="return confirm('Are you sure, Do you want to remove this user?')">
                  Remove User</button>
                  </td>
              </tr>
  
              
  <!--add user-->
              <button class="add" name="adduser" style="border-radius: 10px 10px 10px 10px; height:32px; border-color:green; background-color:green; margin-left:6px; margin-right:6px; width:105px; margin-top: -18px;">
              <a href="add user.php?add=<?php echo $row['email'];?>" style="color:#fff; text-decoration:none" onClick ="return confirm('Are you sure, Do you want to add a user?')">Add User</a></button>
   
        
  <?php
          } 
      }
  ?>      
       
       
      </form>

</div>
   
</body>

</html>