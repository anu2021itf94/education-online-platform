-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 04, 2023 at 09:06 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `studi`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `email` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `password` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`email`, `password`) VALUES
('swarnamalisilva2000@gmail.com', 'swarne2000');

-- --------------------------------------------------------

--
-- Table structure for table `certificate_table`
--

CREATE TABLE `certificate_table` (
  `certi_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `courseid` int(10) NOT NULL,
  `ins_email` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `ins_username` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `course_title` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `course_titleimage` blob NOT NULL,
  `course_description` varchar(255) CHARACTER SET latin1 NOT NULL,
  `material_text` varchar(255) CHARACTER SET latin1 NOT NULL,
  `material_images` longblob NOT NULL,
  `material_videos` blob NOT NULL,
  `material_pdf` mediumblob NOT NULL,
  `material_links` varchar(255) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `enrolled_users`
--

CREATE TABLE `enrolled_users` (
  `courseid` int(10) NOT NULL,
  `course_title` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `user_email` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `user_uname` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `enroll_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `feedback` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `instructor_details`
--

CREATE TABLE `instructor_details` (
  `title` varchar(10) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `fullname` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `username` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `nic` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `education` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `university` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `job` varchar(10) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `email` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `phone` int(10) NOT NULL,
  `password` varchar(15) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `confirmpassword` varchar(15) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `instructor_pic` longblob NOT NULL,
  `reg_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `instructor_details`
--

INSERT INTO `instructor_details` (`title`, `fullname`, `username`, `nic`, `education`, `university`, `job`, `email`, `phone`, `password`, `confirmpassword`, `instructor_pic`, `reg_time`) VALUES
('Miss', 'Lalindya Nethmi Kodikara', 'Lalindya Kodikara', '200069215348', 'Higher National Diploma in Information Technology', 'Advanced Technological Institute - SLIATE', 'No', 'lalindyakodikara3105@gmail.com', 715655436, 'lalindya2000', 'lalindya2000', '', '2023-06-03 05:25:56'),
('Mr.', 'Sakun Ravisanka Premaratne', 'Sakun Ravisanka', '200065947823', 'Higher National Diploma in Information Technology', 'Advanced Technological Institute - SLIATE', 'No', 'sakunravisanka1@gmail.com', 789619294, 'sakun2000', 'sakun2000', '', '2023-06-03 05:33:56'),
('Miss', 'Sithara Thathsarani Ranasinghe', 'Sithara Thathsarani', '200035742519', 'Higher National Diploma in Information Technolog', 'Advanced Technological Institute - SLIATE', 'No', 'sithuthathsarani2000@gmail.com', 740619105, 'sithara2000', 'sithara2000', '', '2023-05-18 12:48:22'),
('Miss', 'Kaushalya S. Silva', 'Kaushalya Silva', '200062548559', 'Higher National Diploma in Information Technology', 'Advanced Technological Institute - SLIATE', 'No', 'swarnamalisilva2000@gmail.com', 774007990, 'ishwari2000', 'ishwari2000', '', '2023-06-03 06:59:34'),
('Miss', 'Vindya S. Wickramasinghe', 'Vindya Wikramasinghe', '200089579845', 'Higher National Diploma in Information Technology', 'Advanced Technological Institute - SLIATE', 'No', 'vindyawickramasinghe03@gmail.com', 719553395, 'vindya2000', 'vindya2000', '', '2023-05-18 12:46:10');

-- --------------------------------------------------------

--
-- Table structure for table `ins_registered`
--

CREATE TABLE `ins_registered` (
  `title` varchar(10) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `fullname` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `username` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `nic` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `education` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `university` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `job` varchar(10) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `email` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `phone` int(10) NOT NULL,
  `password` varchar(15) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `confirmpassword` varchar(15) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `instructor_pic` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `qid` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user_reg`
--

CREATE TABLE `user_reg` (
  `fname` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `lname` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `uname` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `email` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `gender` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `phone` int(10) NOT NULL,
  `password` varchar(15) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `conpass` varchar(15) CHARACTER SET latin1 COLLATE latin1_general_cs NOT NULL,
  `reg_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_reg`
--

INSERT INTO `user_reg` (`fname`, `lname`, `uname`, `email`, `gender`, `phone`, `password`, `conpass`, `reg_time`) VALUES
('Nirmal', 'Swarnahansa', 'Nirmal Swarnahansa', 'silva200kaushalya@gmail.com', 'Male', 770160400, 'nirmal2000', 'nirmal2000', '2023-06-03 11:41:14');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `certificate_table`
--
ALTER TABLE `certificate_table`
  ADD PRIMARY KEY (`certi_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`courseid`),
  ADD KEY `ins_idemail` (`ins_email`);

--
-- Indexes for table `enrolled_users`
--
ALTER TABLE `enrolled_users`
  ADD KEY `course_id` (`courseid`),
  ADD KEY `enrolled_user` (`user_email`);

--
-- Indexes for table `instructor_details`
--
ALTER TABLE `instructor_details`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `ins_registered`
--
ALTER TABLE `ins_registered`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `quiz`
--
ALTER TABLE `quiz`
  ADD PRIMARY KEY (`qid`);

--
-- Indexes for table `user_reg`
--
ALTER TABLE `user_reg`
  ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `courseid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `ins_idemail` FOREIGN KEY (`ins_email`) REFERENCES `ins_registered` (`email`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `enrolled_users`
--
ALTER TABLE `enrolled_users`
  ADD CONSTRAINT `course_id` FOREIGN KEY (`courseid`) REFERENCES `courses` (`courseid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `enrolled_user` FOREIGN KEY (`user_email`) REFERENCES `user_reg` (`email`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
